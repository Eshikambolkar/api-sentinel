/* ══════════════════════════════════════════════════════════════════════════
   API Sentinel — dashboard application
   All metrics, history and findings are fetched from live backend endpoints.
   No hardcoded data anywhere in this file.
   ══════════════════════════════════════════════════════════════════════════ */
"use strict";

// ── Constants ─────────────────────────────────────────────────────────────────

const SEVERITY_ORDER = { critical: 0, high: 1, medium: 2, low: 3, info: 4 };
const SEVERITY_LABEL = { critical: "Critical", high: "High", medium: "Medium", low: "Low", info: "Info" };

// Confidence → human label + tag class
const CONFIDENCE_META = {
  high:   { label: "Confirmed",    tagClass: "tag-confirmed",  confClass: "conf-high"   },
  medium: { label: "Observed",     tagClass: "tag-observed",   confClass: "conf-medium" },
  low:    { label: "Inferred",     tagClass: "tag-inferred",   confClass: "conf-low"    },
};

// ── Core helpers ──────────────────────────────────────────────────────────────

function $(id) { return document.getElementById(id); }

function escHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

async function apiFetch(path, opts = {}) {
  const res = await fetch(path, {
    headers: { "Content-Type": "application/json", ...opts.headers },
    ...opts,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail || `HTTP ${res.status}`);
  }
  return res.json();
}

function relTime(isoStr) {
  if (!isoStr) return "—";
  const d = new Date(isoStr.replace(" ", "T") + "Z");
  const diff = Math.round((Date.now() - d) / 1000);
  if (diff < 5)     return "just now";
  if (diff < 60)    return `${diff}s ago`;
  if (diff < 3600)  return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}

function pill(status) {
  const el = document.createElement("span");
  el.className = `pill pill-${status}`;
  el.textContent = status;
  return el;
}

function severityBadge(sev) {
  const el = document.createElement("span");
  el.className = `badge badge-${sev}`;
  el.textContent = SEVERITY_LABEL[sev] || sev;
  return el;
}

// ════════════════════════════════════════════════════════════════════════════
// TAB SWITCHING
// ════════════════════════════════════════════════════════════════════════════

document.querySelectorAll(".tab-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach(p => p.classList.add("hidden"));
    btn.classList.add("active");
    const panel = $("tab-" + btn.dataset.tab);
    if (panel) panel.classList.remove("hidden");
  });
});

// ════════════════════════════════════════════════════════════════════════════
// FINDING CARD BUILDER
// Shared between dashboard and scanner views.
// ════════════════════════════════════════════════════════════════════════════

/**
 * Build a rich finding card DOM element.
 * @param {object} finding  - FindingOut from backend
 * @param {boolean} expanded - Open by default
 */
function buildFindingCard(finding, expanded = false) {
  const confidence = finding.confidence || "medium";
  const cm = CONFIDENCE_META[confidence] || CONFIDENCE_META.medium;

  const card = document.createElement("div");
  card.className = `finding-card${expanded ? " open" : ""}`;
  card.dataset.sev = finding.severity;
  card.dataset.title = (finding.title || "").toLowerCase();
  card.dataset.category = (finding.category || "").toLowerCase();
  card.dataset.description = (finding.description || "").toLowerCase();

  // Header row
  const header = document.createElement("div");
  header.className = "finding-header";
  header.setAttribute("role", "button");
  header.setAttribute("tabindex", "0");
  header.setAttribute("aria-expanded", expanded ? "true" : "false");

  const badge = severityBadge(finding.severity);

  const titleWrap = document.createElement("span");
  titleWrap.className = "finding-title";
  titleWrap.textContent = finding.title;

  // Confidence tag inline with title
  const confTag = document.createElement("span");
  confTag.className = `conf-tag ${cm.confClass}`;
  confTag.title = `Confidence: ${confidence}`;
  confTag.textContent = cm.label;

  const catEl = document.createElement("span");
  catEl.className = "finding-category";
  catEl.textContent = finding.category;

  const chevron = document.createElement("span");
  chevron.className = "finding-chevron";
  chevron.setAttribute("aria-hidden", "true");
  chevron.textContent = "▶";

  header.append(badge, titleWrap, confTag, catEl, chevron);

  // Body
  const body = document.createElement("div");
  body.className = "finding-body";

  // Description + Remediation
  const dl = document.createElement("dl");

  function addRow(label, value, cls = "") {
    const dt = document.createElement("dt");
    dt.textContent = label;
    const dd = document.createElement("dd");
    if (cls) dd.className = cls;
    dd.textContent = value;
    dl.append(dt, dd);
  }

  addRow("Description",  finding.description);
  addRow("Remediation",  finding.remediation,  "remediation");
  if (finding.affected_url) addRow("Affected URL", finding.affected_url);

  body.appendChild(dl);

  // Evidence block (if present)
  if (finding.evidence && finding.evidence.trim()) {
    const evLabel = document.createElement("dt");
    evLabel.textContent = "Evidence";
    evLabel.style.paddingTop = ".6rem";
    evLabel.style.fontWeight = "700";
    evLabel.style.fontSize = ".75rem";
    evLabel.style.textTransform = "uppercase";
    evLabel.style.letterSpacing = ".05em";
    evLabel.style.color = "var(--muted)";
    evLabel.style.gridColumn = "1 / -1";
    // insert label before evidence block
    const evDl = document.createElement("dl");
    evDl.style.gridTemplateColumns = "1fr";
    evDl.appendChild(evLabel);
    body.appendChild(evDl);

    const evBlock = document.createElement("div");
    evBlock.className = "evidence-block";
    evBlock.textContent = finding.evidence;
    body.appendChild(evBlock);
  }

  // Classification notice
  const classRow = document.createElement("div");
  classRow.className = "classification-row";
  classRow.innerHTML =
    `<span class="tag ${cm.tagClass}">${cm.label}</span>` +
    `<span>Confidence: <strong>${confidence}</strong>` +
    (confidence === "medium" || confidence === "low"
      ? " — absence of a header or heuristic signal; manual verification recommended."
      : " — directly observed in the HTTP response.") +
    `</span>`;
  body.appendChild(classRow);

  // Toggle open/close
  function toggle() {
    card.classList.toggle("open");
    header.setAttribute("aria-expanded", card.classList.contains("open") ? "true" : "false");
  }
  header.addEventListener("click", toggle);
  header.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggle(); } });

  card.append(header, body);
  return card;
}

// ════════════════════════════════════════════════════════════════════════════
// FINDINGS FILTER + SEARCH ENGINE
// ════════════════════════════════════════════════════════════════════════════

/**
 * Wire up a findings toolbar (search input + chips) to filter cards in a list.
 * @param {string} searchId   - id of <input type="search">
 * @param {string} chipsId    - id of chip container
 * @param {string} listId     - id of findings list container
 */
function wireToolbar(searchId, chipsId, listId) {
  const searchEl = $(searchId);
  const chipsEl  = $(chipsId);
  const listEl   = $(listId);

  let activeSev = "all";
  let searchQ   = "";

  function applyFilter() {
    if (!listEl) return;
    const cards = listEl.querySelectorAll(".finding-card");
    let shown = 0;
    cards.forEach(card => {
      const sevMatch = activeSev === "all" || card.dataset.sev === activeSev;
      const textMatch = !searchQ ||
        card.dataset.title.includes(searchQ) ||
        card.dataset.category.includes(searchQ) ||
        card.dataset.description.includes(searchQ);
      const visible = sevMatch && textMatch;
      card.style.display = visible ? "" : "none";
      if (visible) shown++;
    });

    // show/hide "no results" message
    let noRes = listEl.querySelector(".filter-no-results");
    if (shown === 0 && cards.length > 0) {
      if (!noRes) {
        noRes = document.createElement("p");
        noRes.className = "filter-no-results muted";
        noRes.style.padding = ".5rem";
        listEl.appendChild(noRes);
      }
      noRes.textContent = `No findings match "${activeSev !== "all" ? activeSev : ""}${searchQ ? ' "' + searchQ + '"' : ""}".`;
    } else if (noRes) {
      noRes.remove();
    }
  }

  // Chips
  if (chipsEl) {
    chipsEl.querySelectorAll(".chip").forEach(chip => {
      chip.addEventListener("click", () => {
        chipsEl.querySelectorAll(".chip").forEach(c => c.classList.remove("active"));
        chip.classList.add("active");
        activeSev = chip.dataset.sev;
        applyFilter();
      });
    });
  }

  // Search
  if (searchEl) {
    searchEl.addEventListener("input", () => {
      searchQ = searchEl.value.trim().toLowerCase();
      applyFilter();
    });
  }

  return { applyFilter };
}

// ════════════════════════════════════════════════════════════════════════════
// EXPORT HELPERS  (JSON and printable HTML report)
// ════════════════════════════════════════════════════════════════════════════

function downloadJson(obj, filename) {
  const blob = new Blob([JSON.stringify(obj, null, 2)], { type: "application/json" });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement("a");
  a.href     = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function buildPrintableReport(scan) {
  const ts   = new Date().toLocaleString();
  const rows = (scan.findings || []).map(f => {
    const cm = CONFIDENCE_META[f.confidence] || CONFIDENCE_META.medium;
    return `
      <div style="margin-bottom:1.2rem;padding:1rem;border:1px solid #e5e7eb;border-radius:6px;border-left:4px solid ${sevColour(f.severity)}">
        <div style="display:flex;align-items:center;gap:.6rem;margin-bottom:.5rem">
          <span style="background:${sevBg(f.severity)};color:${sevColour(f.severity)};font-size:.72rem;font-weight:700;padding:.18rem .5rem;border-radius:4px;text-transform:uppercase">${escHtml(SEVERITY_LABEL[f.severity])}</span>
          <strong style="font-size:.93rem">${escHtml(f.title)}</strong>
          <span style="font-size:.72rem;border:1px solid ${cmColour(cm)};color:${cmColour(cm)};padding:.1rem .4rem;border-radius:3px;text-transform:uppercase;opacity:.75">${escHtml(cm.label)}</span>
          <span style="margin-left:auto;font-size:.8rem;color:#57606a">${escHtml(f.category)}</span>
        </div>
        <p style="font-size:.88rem;color:#374151;margin-bottom:.4rem">${escHtml(f.description)}</p>
        <p style="font-size:.88rem;color:#1a7f37;font-weight:500;margin-bottom:.4rem"><strong>Remediation:</strong> ${escHtml(f.remediation)}</p>
        ${f.affected_url ? `<p style="font-size:.8rem;color:#57606a"><strong>Affected URL:</strong> ${escHtml(f.affected_url)}</p>` : ""}
        ${f.evidence ? `<pre style="margin-top:.5rem;background:#f0f2f5;border:1px solid #e5e7eb;border-radius:5px;padding:.55rem .8rem;font-size:.76rem;white-space:pre-wrap;word-break:break-all">${escHtml(f.evidence)}</pre>` : ""}
      </div>`;
  }).join("");

  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<title>API Sentinel Report — ${escHtml(scan.target_url)}</title>
<style>body{font-family:-apple-system,"Segoe UI",system-ui,sans-serif;max-width:860px;margin:2rem auto;padding:1rem;color:#1f2328;line-height:1.6}
h1{font-size:1.3rem}h2{font-size:1rem;margin-bottom:.75rem}table{border-collapse:collapse;width:100%;margin-bottom:1.5rem}
th,td{padding:.4rem .65rem;text-align:left;border-bottom:1px solid #e5e7eb;font-size:.88rem}
th{font-size:.75rem;text-transform:uppercase;letter-spacing:.04em;color:#57606a}
.notice{font-size:.8rem;color:#57606a;margin-top:.4rem}
</style></head><body>
<div style="border-bottom:2px solid #1f2328;padding-bottom:1rem;margin-bottom:1.5rem">
  <h1>API Sentinel Security Report</h1>
  <p style="color:#57606a;font-size:.9rem">Generated: ${escHtml(ts)} &nbsp;·&nbsp; Target: <strong>${escHtml(scan.target_url)}</strong></p>
  <p class="notice">⚠ Findings marked <em>Observed</em> or <em>Inferred</em> reflect the absence of recommended headers or heuristic signals and should be verified manually before treating as confirmed vulnerabilities.</p>
</div>
<h2>Summary</h2>
<table>
  <tr><th>Severity</th><th>Count</th></tr>
  ${["critical","high","medium","low","info"].map(s => {
    const cnt = (scan.findings||[]).filter(f=>f.severity===s).length;
    return `<tr><td>${SEVERITY_LABEL[s]}</td><td>${cnt}</td></tr>`;
  }).join("")}
  <tr><td><strong>Total</strong></td><td><strong>${(scan.findings||[]).length}</strong></td></tr>
</table>
<h2>Findings</h2>
${rows || '<p style="color:#57606a">No findings recorded.</p>'}
<p style="font-size:.75rem;color:#aaa;margin-top:2rem;border-top:1px solid #e5e7eb;padding-top:.75rem">
  Produced by API Sentinel &mdash; local security assessment tool. No data was transmitted externally.
</p></body></html>`;
}

function sevColour(s) {
  return {critical:"#b91c1c",high:"#c2410c",medium:"#854d0e",low:"#1a7f37",info:"#1d4ed8"}[s] || "#57606a";
}
function sevBg(s) {
  return {critical:"#fde8e8",high:"#fff0e6",medium:"#fefce8",low:"#f0fdf4",info:"#eff6ff"}[s] || "#f7f8fa";
}
function cmColour(cm) {
  if (cm.confClass === "conf-high")   return "#b91c1c";
  if (cm.confClass === "conf-medium") return "#c57c00";
  return "#57606a";
}

function openPrintWindow(html) {
  const w = window.open("", "_blank");
  if (!w) { alert("Please allow pop-ups to export the report."); return; }
  w.document.write(html);
  w.document.close();
  w.focus();
  w.print();
}

// ════════════════════════════════════════════════════════════════════════════
// DASHBOARD TAB
// ════════════════════════════════════════════════════════════════════════════

let _currentDashScan = null;  // the scan currently displayed in the right panel

// Wire dashboard toolbar
const dashFilter = wireToolbar("findingSearch", "filterChips", "dashFindingsList");

// ── Stats ─────────────────────────────────────────────────────────────────────

async function loadStats() {
  try {
    const s = await apiFetch("/api/stats");
    // Remove skeleton loaders
    ["statTotalScans","statTotalFindings","statCritical","statHigh","statMedium","statLow"]
      .forEach(id => { const el = $(id); if (el) el.innerHTML = ""; });

    $("statTotalScans").textContent    = s.total_scans;
    $("statTotalFindings").textContent = s.total_findings;
    $("statCritical").textContent      = s.critical;
    $("statHigh").textContent          = s.high;
    $("statMedium").textContent        = s.medium;
    $("statLow").textContent           = s.low + s.info;

    // remove loading classes
    document.querySelectorAll(".stat-card.stat-loading").forEach(c => c.classList.remove("stat-loading"));
  } catch (e) {
    // non-fatal: show dashes
    ["statTotalScans","statTotalFindings","statCritical","statHigh","statMedium","statLow"]
      .forEach(id => { const el = $(id); if (el) el.textContent = "—"; });
  }
}

// ── Scan history (dashboard left column) ─────────────────────────────────────

async function loadDashHistory() {
  const wrap = $("dashHistoryWrap");
  try {
    const scans = await apiFetch("/api/scans");
    if (!scans || scans.length === 0) {
      wrap.innerHTML = `<div class="empty-state"><p class="empty-icon">📋</p><p>No scans yet.</p></div>`;
      return;
    }

    const list = document.createElement("div");
    list.className = "scan-list";

    scans.forEach(s => {
      const row = document.createElement("div");
      row.className = "scan-row";
      row.dataset.scanId = s.id;

      const statusEl = document.createElement("span");
      statusEl.appendChild(pill(s.status));

      const urlEl = document.createElement("span");
      urlEl.className = "scan-row-url";
      urlEl.title = s.target_url;
      urlEl.textContent = s.target_url;

      const countEl = document.createElement("span");
      countEl.className = "scan-row-count";
      countEl.textContent = s.finding_count > 0 ? `${s.finding_count} ⚑` : "0";

      const metaEl = document.createElement("span");
      metaEl.className = "scan-row-meta";
      metaEl.textContent = relTime(s.created_at);

      row.append(statusEl, urlEl, countEl, metaEl);

      row.addEventListener("click", () => {
        document.querySelectorAll(".scan-row.selected").forEach(r => r.classList.remove("selected"));
        row.classList.add("selected");
        loadDashFindings(s.id, s.target_url);
      });

      list.appendChild(row);
    });

    wrap.innerHTML = "";
    wrap.appendChild(list);
  } catch (e) {
    wrap.innerHTML = `<div class="error-state">Failed to load history: ${escHtml(e.message)}</div>`;
  }
}

// ── Findings panel (dashboard right column) ───────────────────────────────────

async function loadDashFindings(scanId, targetUrl) {
  const titleEl  = $("dashFindingsTitle");
  const listEl   = $("dashFindingsList");
  const toolbar  = $("findingsToolbar");
  const exportRow = $("dashExportRow");

  titleEl.textContent = targetUrl || `Scan #${scanId}`;
  listEl.innerHTML = `<div class="skeleton-rows">
    <div class="skeleton-row"></div><div class="skeleton-row"></div><div class="skeleton-row"></div>
  </div>`;
  toolbar.classList.add("hidden");
  exportRow.classList.add("hidden");

  try {
    const scan = await apiFetch(`/api/scans/${scanId}`);
    _currentDashScan = scan;

    listEl.innerHTML = "";

    // Reset filter chips
    const chipsEl = $("filterChips");
    if (chipsEl) chipsEl.querySelectorAll(".chip").forEach(c => c.classList.toggle("active", c.dataset.sev === "all"));
    const searchEl = $("findingSearch");
    if (searchEl) searchEl.value = "";

    if (!scan.findings || scan.findings.length === 0) {
      if (scan.status === "running") {
        listEl.innerHTML = `<div class="empty-state"><span class="spinner spinner-accent" aria-hidden="true" style="margin:auto"></span><p style="margin-top:.5rem">Scan in progress…</p></div>`;
      } else {
        listEl.innerHTML = `<div class="no-findings">✓ No issues found for this scan.</div>`;
      }
      return;
    }

    scan.findings.forEach(f => listEl.appendChild(buildFindingCard(f)));

    toolbar.classList.remove("hidden");
    exportRow.classList.remove("hidden");

    // Wire export buttons
    $("exportJsonBtn").onclick = () => downloadJson(scan, `sentinel-scan-${scanId}.json`);
    $("exportHtmlBtn").onclick = () => openPrintWindow(buildPrintableReport(scan));

  } catch (e) {
    listEl.innerHTML = `<div class="error-state">Failed to load findings: ${escHtml(e.message)}</div>`;
  }
}

// Refresh button
$("dashRefreshBtn").addEventListener("click", () => {
  loadStats();
  loadDashHistory();
});

// Initial dashboard load
(async () => {
  await Promise.all([loadStats(), loadDashHistory()]);
})();

// ════════════════════════════════════════════════════════════════════════════
// SCANNER TAB
// ════════════════════════════════════════════════════════════════════════════

let _currentScanData = null;

// Wire scanner toolbar
wireToolbar("scanFindingSearch", "scanFilterChips", "findingsList");

// ── Render findings into the scanner results panel ────────────────────────────

function renderScanFindings(scan) {
  _currentScanData = scan;

  const section  = $("resultsSection");
  const title    = $("resultsTitle");
  const badges   = $("severityBadges");
  const list     = $("findingsList");
  const toolbar  = $("scanToolbar");
  const exportRow = $("scanExportRow");
  const searchEl = $("scanFindingSearch");
  const chips    = $("scanFilterChips");

  title.textContent = `Results — ${scan.target_url}`;
  badges.innerHTML  = "";
  list.innerHTML    = "";
  if (searchEl) searchEl.value = "";
  if (chips) chips.querySelectorAll(".chip").forEach(c => c.classList.toggle("active", c.dataset.sev === "all"));

  if (!scan.findings || scan.findings.length === 0) {
    list.innerHTML = `<div class="no-findings">✓ No issues found. Always verify manually!</div>`;
    toolbar.classList.add("hidden");
    exportRow.classList.add("hidden");
    section.classList.remove("hidden");
    return;
  }

  // Severity summary badges
  const counts = {};
  scan.findings.forEach(f => { counts[f.severity] = (counts[f.severity] || 0) + 1; });
  Object.keys(SEVERITY_ORDER).forEach(sev => {
    if (counts[sev]) {
      const b = severityBadge(sev);
      b.textContent = `${SEVERITY_LABEL[sev]}: ${counts[sev]}`;
      badges.appendChild(b);
    }
  });

  scan.findings.forEach(f => list.appendChild(buildFindingCard(f)));

  toolbar.classList.remove("hidden");
  exportRow.classList.remove("hidden");

  // Export buttons
  $("scanExportJsonBtn").onclick = () => downloadJson(scan, `sentinel-scan-${scan.id}.json`);
  $("scanExportHtmlBtn").onclick = () => openPrintWindow(buildPrintableReport(scan));

  section.classList.remove("hidden");
}

// ── Poll scan ─────────────────────────────────────────────────────────────────

async function pollScan(scanId, targetUrl) {
  const statusCard = $("scanStatus");
  const statusText = $("statusText");
  const statusSub  = $("statusSub");

  statusText.textContent = "Scanning…";
  statusSub.textContent  = targetUrl;
  statusCard.classList.remove("hidden");
  $("resultsSection").classList.add("hidden");

  for (let i = 0; i < 120; i++) {
    await new Promise(r => setTimeout(r, 1500));
    try {
      const scan = await apiFetch(`/api/scans/${scanId}`);
      if (scan.status === "done" || scan.status === "failed") {
        statusCard.classList.add("hidden");
        if (scan.status === "failed") {
          $("formError").textContent = "Scan failed. Check the target URL and try again.";
          $("formError").classList.remove("hidden");
        } else {
          renderScanFindings(scan);
          // Refresh dashboard stats + history silently
          loadStats();
          loadDashHistory();
        }
        return;
      }
    } catch (e) {
      statusText.textContent = `Polling error: ${e.message}`;
      return;
    }
  }
  statusText.textContent = "Scan timed out.";
}

// ── Scan form ─────────────────────────────────────────────────────────────────

$("scanForm").addEventListener("submit", async e => {
  e.preventDefault();
  const url     = $("targetUrl").value.trim();
  const btn     = $("scanBtn");
  const errEl   = $("formError");
  const spinner = $("btnSpinner");
  const btnText = $("btnText");

  errEl.classList.add("hidden");
  btn.disabled = true;
  spinner.classList.remove("hidden");
  btnText.textContent = "Starting…";

  try {
    const data = await apiFetch("/api/scans", {
      method: "POST",
      body:   JSON.stringify({ target_url: url }),
    });
    await pollScan(data.scan_id, url);
  } catch (err) {
    errEl.textContent = err.message;
    errEl.classList.remove("hidden");
  } finally {
    btn.disabled = false;
    spinner.classList.add("hidden");
    btnText.textContent = "Run Scan";
  }
});

// ════════════════════════════════════════════════════════════════════════════
// BOLA / IDOR LAB TAB
// ════════════════════════════════════════════════════════════════════════════

let labMode = "vulnerable";
let _labResultData = null;

const LAB_MODES = {
  vulnerable: "<strong>Vulnerable:</strong> object-ownership checks are omitted. Cross-user access is expected to succeed — demonstrating the vulnerability.",
  secure:     "<strong>Secure:</strong> ownership is enforced. Cross-user access must be rejected with HTTP 403. Expect all tests to PASS.",
};

// ── Load demo setup info ──────────────────────────────────────────────────────

async function loadLabInfo() {
  const wrap = $("labUsers");
  try {
    const info = await apiFetch("/api/lab/info");
    const recsByUser = {};
    info.records.forEach(r => {
      if (!recsByUser[r.owner]) recsByUser[r.owner] = [];
      recsByUser[r.owner].push(r);
    });
    wrap.innerHTML = "";
    info.users.forEach(u => {
      const card = document.createElement("div");
      card.className = "lab-user-card";
      const recs = recsByUser[u.username] || [];
      card.innerHTML = `
        <div class="user-name">${escHtml(u.username)}</div>
        <div class="user-records">
          ${recs.map(r => `<div class="record-item">Record #${r.id}: ${escHtml(r.title)}</div>`).join("")}
        </div>`;
      wrap.appendChild(card);
    });
  } catch (e) {
    wrap.innerHTML = `<p class="muted">Failed to load lab info: ${escHtml(e.message)}</p>`;
  }
}

// ── Mode toggle ───────────────────────────────────────────────────────────────

function setLabMode(mode) {
  labMode = mode;
  $("labModeDesc").innerHTML = LAB_MODES[mode];
  $("modeVulnBtn").classList.toggle("active", mode === "vulnerable");
  $("modeSecureBtn").classList.toggle("active", mode === "secure");
  $("labResults").classList.add("hidden");
  $("labExportRow").classList.add("hidden");
}

$("modeVulnBtn").addEventListener("click",  () => setLabMode("vulnerable"));
$("modeSecureBtn").addEventListener("click", () => setLabMode("secure"));

// ── Run lab tests ─────────────────────────────────────────────────────────────

$("runLabBtn").addEventListener("click", async () => {
  const btn     = $("runLabBtn");
  const spinner = $("labBtnSpinner");
  const btnText = $("labBtnText");
  const errEl   = $("labResultsTitle");

  btn.disabled = true;
  spinner.classList.remove("hidden");
  btnText.textContent = "Running…";
  $("labResults").classList.add("hidden");

  try {
    const secure = labMode === "secure";
    const result = await apiFetch(`/api/lab/bola?secure=${secure}`, { method: "POST" });
    _labResultData = result;
    renderLabResults(result);
  } catch (e) {
    errEl.textContent = `Error: ${escHtml(e.message)}`;
    $("labResults").classList.remove("hidden");
  } finally {
    btn.disabled = false;
    spinner.classList.add("hidden");
    btnText.textContent = "Run BOLA Tests";
  }
});

// ── Export wiring ─────────────────────────────────────────────────────────────

$("labExportJsonBtn").addEventListener("click", () => {
  if (_labResultData) downloadJson(_labResultData, `sentinel-bola-${_labResultData.mode}.json`);
});
$("labExportHtmlBtn").addEventListener("click", () => {
  if (_labResultData) openPrintWindow(buildBolaReport(_labResultData));
});

// ── Render BOLA results ───────────────────────────────────────────────────────

function renderLabResults(result) {
  const section      = $("labResults");
  const title        = $("labResultsTitle");
  const overallBadge = $("labOverallBadge");
  const modeBadge    = $("labModeBadge");
  const listEl       = $("labScenarioList");
  const exportRow    = $("labExportRow");

  title.textContent = `${result.total} scenario(s) · ${result.passed} passed · ${result.failed} failed`;
  overallBadge.textContent = result.overall_verdict;
  overallBadge.className   = `badge badge-${result.overall_verdict.toLowerCase()}`;
  modeBadge.textContent    = result.mode === "vulnerable" ? "Vulnerable API" : "Secure API";
  modeBadge.className      = `badge badge-${result.mode === "vulnerable" ? "vuln" : "secure"}`;

  listEl.innerHTML = "";
  const ul = document.createElement("div");
  ul.className = "scenario-list";

  result.scenarios.forEach(s => {
    const card = document.createElement("div");
    card.className = `scenario-card verdict-${s.verdict.toLowerCase()}`;

    const statusCls = s.actual_status < 300 ? "http-status-ok" : "http-evidence-err";
    const evidLines = [
      `<span class="http-method">GET</span> ${escHtml(s.request_url)}`,
      `Authorization: ${escHtml((s.request_headers || {})["Authorization"] || "")}`,
      "",
      `HTTP <span class="${statusCls}">${s.actual_status}</span>`,
      escHtml(s.actual_body),
    ].join("\n");

    card.innerHTML = `
      <div class="scenario-header">
        <span class="scenario-id">${escHtml(s.scenario_id)}</span>
        <span class="scenario-title">${escHtml(s.title)}</span>
        <span class="scenario-status-badge status-${s.verdict.toLowerCase()}">${s.verdict}</span>
        <span class="scenario-chevron" aria-hidden="true">▶</span>
      </div>
      <div class="scenario-body">
        <dl>
          <dt>Description</dt>   <dd>${escHtml(s.description)}</dd>
          <dt>Attacker</dt>      <dd>${escHtml(s.attacker)} (token: ${escHtml(s.attacker_token_display || "")})</dd>
          <dt>Victim's record</dt><dd>Record #${s.record_id} — owned by <strong>${escHtml(s.victim)}</strong></dd>
          <dt>Expected status</dt><dd>HTTP ${s.expected_status} (Forbidden or Not Found)</dd>
          <dt>Actual status</dt> <dd><strong>HTTP ${s.actual_status}</strong></dd>
        </dl>
        <div class="verdict-block verdict-${s.verdict.toLowerCase()}">${escHtml(s.verdict_reason)}</div>
        <div class="http-evidence">${evidLines}</div>
      </div>`;

    card.querySelector(".scenario-header").addEventListener("click", () => {
      card.classList.toggle("open");
    });
    ul.appendChild(card);
  });

  listEl.appendChild(ul);
  section.classList.remove("hidden");
  exportRow.classList.remove("hidden");
}

// ── BOLA printable report ─────────────────────────────────────────────────────

function buildBolaReport(result) {
  const ts = new Date().toLocaleString();
  const rows = (result.scenarios || []).map(s => `
    <tr style="background:${s.verdict==="FAIL"?"#fde8e8":"#f0fdf4"}">
      <td>${escHtml(s.scenario_id)}</td>
      <td>${escHtml(s.attacker)} → record #${s.record_id} (${escHtml(s.victim)})</td>
      <td><strong>HTTP ${s.actual_status}</strong></td>
      <td><strong style="color:${s.verdict==="FAIL"?"#b91c1c":"#1a7f37"}">${s.verdict}</strong></td>
      <td style="font-size:.82rem">${escHtml(s.verdict_reason)}</td>
    </tr>`).join("");

  return `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<title>API Sentinel BOLA Report — ${escHtml(result.mode)}</title>
<style>body{font-family:-apple-system,"Segoe UI",sans-serif;max-width:900px;margin:2rem auto;padding:1rem;color:#1f2328;line-height:1.5}
h1{font-size:1.3rem}h2{font-size:1rem;margin:1.5rem 0 .75rem}
table{width:100%;border-collapse:collapse;font-size:.86rem}
th,td{padding:.45rem .65rem;border-bottom:1px solid #e5e7eb;text-align:left;vertical-align:top}
th{font-size:.74rem;text-transform:uppercase;color:#57606a;letter-spacing:.04em}
.notice{font-size:.8rem;color:#57606a;margin:.5rem 0 1rem}
</style></head><body>
<div style="border-bottom:2px solid #1f2328;padding-bottom:1rem;margin-bottom:1.5rem">
  <h1>API Sentinel — BOLA / IDOR Test Report</h1>
  <p style="color:#57606a">Generated: ${escHtml(ts)} &nbsp;·&nbsp; Mode: <strong>${escHtml(result.mode)}</strong>
     &nbsp;·&nbsp; Overall: <strong style="color:${result.overall_verdict==="PASS"?"#1a7f37":"#b91c1c"}">${result.overall_verdict}</strong></p>
</div>
<p class="notice">⚠ This lab uses synthetic data only. The "vulnerable" mode intentionally omits ownership checks to demonstrate BOLA (OWASP API Security #1). Results from the "secure" mode confirm the fix is effective.</p>
<h2>Scenarios</h2>
<table>
  <thead><tr><th>ID</th><th>Scenario</th><th>HTTP Status</th><th>Verdict</th><th>Reason</th></tr></thead>
  <tbody>${rows}</tbody>
</table>
<p style="font-size:.75rem;color:#aaa;margin-top:2rem;border-top:1px solid #e5e7eb;padding-top:.75rem">
  Produced by API Sentinel &mdash; local security assessment tool.
</p></body></html>`;
}

// ── Initial lab load ──────────────────────────────────────────────────────────

loadLabInfo();
